﻿namespace Telephony.Models.Interfaces
{
    public interface IBrowse
    {
        string BrowseTheInternet(string websiteUrl);
    }
}
