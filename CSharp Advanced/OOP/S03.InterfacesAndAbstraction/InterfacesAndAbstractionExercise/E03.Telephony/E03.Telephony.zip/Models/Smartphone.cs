﻿using System;
using System.Text.RegularExpressions;
using Telephony.Models.Interfaces;

namespace Telephony.Models
{
    public class Smartphone : ICall, IBrowse
    {
        private const string paternUrl = @"^http://[a-z]+.[a-z]+$";
        private Regex urlCheck;

        private const string paternPhoneNumber = @"^[0-9]{10}$";
        private Regex phoneNumberCheck;

        private Match matchSuccess;

        public Smartphone()
        {
            urlCheck = new Regex(paternUrl);
            phoneNumberCheck = new Regex(paternPhoneNumber);
        }

        public string BrowseTheInternet(string websiteUrl)
        {

            matchSuccess = urlCheck.Match(websiteUrl);

            if (matchSuccess.Success)
            {
              return  $"Browsing: {websiteUrl}!";
            }
            else
            {
                return "Invalid URL!";
            }
        }

        public string CallSomeone(string number)
        {
            matchSuccess = phoneNumberCheck.Match(number);

            if (matchSuccess.Success)
            {
                return $"Calling... {number}";
            }
            else
            {
                return "Invalid number!";
            }


        }
    }
}
